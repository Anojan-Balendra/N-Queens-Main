# N-Queens

## Problem Definition
The n-queens puzzle is the problem of placing n queens on an n x n chessboard such that no two queens attack each other.
